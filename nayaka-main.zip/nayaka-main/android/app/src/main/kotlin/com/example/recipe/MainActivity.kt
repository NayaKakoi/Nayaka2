package com.example.recipe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
