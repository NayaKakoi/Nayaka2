import 'package:flutter/material.dart';

Color background = Color(0xfff6f4fa);
Color maincolor = Color(0xfff96163);
Color font = Color(0xfff3C444C);
